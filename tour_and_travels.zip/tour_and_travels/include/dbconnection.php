<?php
ini_set('mysql.connect_timeout', 300);
ini_set('default_socket_timeout', 300); 
date_default_timezone_set("Asia/Kolkata");
if(!isset($_SESSION)){
    session_start();
} 
ob_start();


$serverName=$_SERVER["HTTP_HOST"]=="localhost"?"root":"root";
$serverPassword=$_SERVER["HTTP_HOST"]=="localhost"?"":"";

$connection=mysqli_connect("localhost",$serverName,$serverPassword)or dir("Database Connection Failed.");

if(!$connection)
{
    die("Database Connection Failed : " . mysqli_error($connection));
}
else
{
    mysqli_select_db($connection,"tours") or die("Database Selection Failed : " . mysqli_error($connection));
      
}
?>