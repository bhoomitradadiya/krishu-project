<?php
$pagename="Add Package";
include("../include/header.php");
$no=1;
$flag=0;

$query=mysqli_query($connection,"SELECT * FROM `booking` LEFT JOIN `user` ON `user`.`userId`= `booking`.`userId` WHERE `booking`.`status`=2 AND `booking`.`delete`=0 ORDER BY `bookingId` DESC");

if(isset($_POST['submit']))
{
    $packageName=isset($_POST['packageName'])?$_POST['packageName']:"";
    $price=isset($_POST['price'])?$_POST['price']:"";
    $description=isset($_POST['description'])?$_POST['description']:"";
    $day=isset($_POST['days'])?$_POST['days']:"";
    if($packageName=="" || $packageName==NULL)
    {
        $nameerror="<span class='error'>Package Name Required</span>";
        $flag=1;
    }
    if($price=="" || $price==NULL)
    {
        $priceerror="<span class='error'>Package Price Required</span>";
        $flag=1;
    }
    if($description=="" || $description==NULL)
    {
        $descriptionerror="<span class='error'>Description Required</span>";
        $flag=1;
    }
    if($day=="" || $day==NULL)
    {
        $dayerror="<span class='error'>Package Day Required</span>";
        $flag=1;
    }

    if($flag==0)
    {
        $query="INSERT INTO `package` SET `packageName`='".$packageName."',`price`='".$price."',`description`='".$description."',`day`='".$day."'";
        if(mysqli_query($connection,$query))
        {
            echo "success";
            $success=1;
        }
        else
        {
            echo "something has goes to wrond";
            $error=1;
        }
    }
}
?>
    <!--begin::Container-->
    <div class="d-flex flex-row flex-column-fluid container">
        <div class="main d-flex flex-column flex-row-fluid">
            
							<div class="content flex-column-fluid" id="kt_content">
								
								<!--begin::Card-->
								<div class="card card-custom">
									<div class="card-header flex-wrap py-5">
										<div class="card-title">
											<h3 class="card-label"><?php echo $pagename; ?></h3>
										</div>
										<div class="card-toolbar">
											
										</div>
									</div>
									<div class="card-body">
                                        <form class="form" method="post">
                                            <div class="card-body row">
                                                <div class="form-group cols-lg-6 cols-md-6 cols-sm-12 ml-3">
                                                    <label>Package Name:</label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="Enter package name" name="packageName"/>
                                                    <?php if(isset($nameerror)){echo $nameerror;} ?>
                                                </div>
                                                <div class="form-group cols-lg-6 cols-md-6 cols-sm-12 ml-3">
                                                    <label>price:</label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="Enter price" name="price"/>
                                                    <?php if(isset($priceerror)){echo $priceerror;} ?>
                                                </div>
                                                <div class="form-group cols-lg-6 cols-md-6 cols-sm-12 ml-3">
                                                    <label>Description</label>
                                                    <div class="input-group input-group-lg">
                                                        <textarea class="form-control" rows="3" name="description"></textarea>
                                                        <?php if(isset($descriptionerror)){echo $descriptionerror;} ?>
                                                        <!-- <input type="text" class="form-control form-control-solid" placeholder="99.9"/> -->
                                                    </div>
                                                </div>
                                                <div class="form-group cols-lg-6 cols-md-6 cols-sm-12 ml-3">
                                                    <label>Day:</label>
                                                    <select class="form-control form-control-solid" name="days">
                                                        <option value="">Select Day</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                    </select>
                                                    <?php if(isset($dayerror)){echo $dayerror;} ?>
                                                </div>
                                            </div>
                                            <!-- </div> -->
                                            <div class="card-footer">
                                            <button type="submit" class="btn btn-primary mr-2" name="submit">Submit</button>
                                            <button type="button" class="btn btn-secondary" onclick="window.location.href='../packageview/'">Cancel</button>
                                            </div>
                                        </form>
									</div>
								</div>
								<!--end::Card-->
							</div>
							<!--end::Content-->

							
    <!--end::Container-->

<?php
include("../include/footer.php");
?>
